/*  All movies released in 2008 */

SELECT title FROM movies WHERE year = 2008;